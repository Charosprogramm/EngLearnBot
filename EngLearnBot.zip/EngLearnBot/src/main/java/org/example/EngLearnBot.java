package org.example;

import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.methods.updatingmessages.DeleteMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EngLearnBot extends TelegramLongPollingBot {
    private final Map<String, String> wordDictionary = new HashMap<>(); // Map to hold word translations
    private final Map<Long, Boolean> awaitingTranslation = new HashMap<>(); // To track if we're awaiting a word to translate
    Map<Long, Integer> currentQuestionIndex = new HashMap<>();
    Map<Long, Integer> awaitingTestConfirmation = new HashMap<>();
    Map<Long, Integer> correctAnswers = new HashMap<>();

    List<String> questions = List.of(
            "1. Select the correct verb form:\nHe _______ to the store every day.\nA) go\nB) goes\nC) going",
            "2. Choose the correct preposition:\nI am going _______ London next week.\nA) to\nB) at\nC) in",
            "3. Identify the correct tense:\nThey _______ here since morning.\nA) have been\nB) has been\nC) is been",
            "4. Determine the correct comparative form:\nShe is _______ than her brother.\nA) more tall\nB) taller\nC) more taller",
            "5. Choose the correct pronoun:\n_______ book is this?\nA) Who's\nB) Whose\nC) Who"
    );



    List<String> correctAnswersList = List.of("B", "A", "A", "B", "B");

    @Override
    public void onUpdateReceived(Update update) {
        long chatId;

        if (update.hasCallbackQuery()) {
            chatId = update.getCallbackQuery().getMessage().getChatId();
            String callbackData = update.getCallbackQuery().getData();
            int messageId = update.getCallbackQuery().getMessage().getMessageId();

            switch (callbackData) {
                case "test":
                    awaitingTestConfirmation.put(chatId, messageId);
                    askUserIfReady(chatId);
                    break;

                case "ready":
                    startTest(chatId);
                    break;

                case "not_ready":
                    sendResponse(chatId, "Test canceled. You can start it later with /start.");
                    break;

                case "back":
                    sendWelcomeMessage(chatId);
                    break;

                case "study":
                    Study(chatId);
                    break;

                case "translator":
                    askForWord(chatId);
                    break;

                case "level":
sendLevel(chatId);
break;
                case "beginner":
                    Beginner(chatId);
                    break;
            }
        } else if (update.hasMessage() && update.getMessage().hasText()) {
            chatId = update.getMessage().getChatId();
            String text = update.getMessage().getText();

            if (text.equalsIgnoreCase("/start")) {
                sendWelcomeMessage(chatId);
            } else if (awaitingTranslation.getOrDefault(chatId, false)) {
                awaitingTranslation.put(chatId, false); // Stop waiting for a word
                String translatedWord = wordDictionary.get(text.trim().toLowerCase());
                if (translatedWord != null) {
                    sendResponse(chatId, "The translation is: " + translatedWord);
                } else {
                    sendResponse(chatId, "The word is not in our dictionary.");
                }
            } else if (currentQuestionIndex.containsKey(chatId)) {
                Integer questionIndex = currentQuestionIndex.get(chatId);

                if (questionIndex != null) {
                    if (questionIndex < questions.size()) {
                        String userAnswer = text.trim().toUpperCase();

                        if (userAnswer.equals(correctAnswersList.get(questionIndex))) {
                            correctAnswers.put(chatId, correctAnswers.getOrDefault(chatId, 0) + 1);
                        }

                        questionIndex++;
                        currentQuestionIndex.put(chatId, questionIndex);

                        if (questionIndex < questions.size()) {
                            sendQuestion(chatId);
                        } else {
                            sendTestCompleteMessage(chatId);
                            correctAnswers.remove(chatId);
                            currentQuestionIndex.remove(chatId);
                        }
                    }
                }
            }
        }
    }

    public EngLearnBot() {
        // Load the word list from the file
        loadWordList("C:\\Users\\Droid\\IdeaProjects\\EngLearnBot\\src\\main\\resources\\wordList.txt");
    }

    private void loadWordList(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("#"); // Split based on '#'
                if (parts.length >= 3) { // Ensure there's enough parts to process
                    String englishWord = parts[0].trim().toLowerCase(); // English word
                    String uzbekTranslation = parts[1].trim(); // Uzbek translation
                    String exampleSentence = parts[2].trim(); // Example sentence

                    // Store the translation and example in the dictionary
                    wordDictionary.put(englishWord, uzbekTranslation + " | " + exampleSentence);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading word list file: " + e.getMessage());
            e.printStackTrace();
        }
    }


    private void askUserIfReady(long chatId) {
        SendMessage readyMessage = new SendMessage();
        readyMessage.setChatId(String.valueOf(chatId));
        readyMessage.setText("Are you ready to start the test?");

        InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup();
        inlineKeyboard.setKeyboard(
                List.of(
                        List.of(
                                InlineKeyboardButton.builder().text("Yes").callbackData("ready").build(),
                                InlineKeyboardButton.builder().text("No").callbackData("not_ready").build(),
                                InlineKeyboardButton.builder().text("Back").callbackData("back").build()
                        )
                )
        );

        readyMessage.setReplyMarkup(inlineKeyboard);

        try {
            execute(readyMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    private void askForWord(long chatId) {
        awaitingTranslation.put(chatId, true); // Set the state to awaiting a word
        SendMessage message = new SendMessage();
        message.setChatId(String.valueOf(chatId));
        message.setText("Please enter the word you want to translate to Uzbek:");

        try {
            execute(message);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    private void startTest(long chatId) {
        Integer messageId = awaitingTestConfirmation.remove(chatId);
        if (messageId != null) {
            DeleteMessage deleteMessage = new DeleteMessage();
            deleteMessage.setChatId(String.valueOf(chatId));
            deleteMessage.setMessageId(messageId);

            try {
                execute(deleteMessage);
            } catch (TelegramApiException e) {
                e.printStackTrace();
            }
        }

        currentQuestionIndex.put(chatId, 0);
        correctAnswers.put(chatId, 0);
        sendQuestion(chatId);
    }

    private void sendQuestion(long chatId) {
        Integer questionIndex = currentQuestionIndex.get(chatId);

        if (questionIndex != null && questionIndex < questions.size()) {
            SendMessage questionMessage = new SendMessage();
            questionMessage.setChatId(String.valueOf(chatId));
            questionMessage.setText(questions.get(questionIndex));

            try {
                execute(questionMessage);
            } catch (TelegramApiException e) {
                throw new RuntimeException(e);
            }
        }
    }

    // Declare the map to store user levels
    Map<Long, String> userLevels = new HashMap<>();

    void sendTestCompleteMessage(long chatId) {
        int correctCount = correctAnswers.getOrDefault(chatId, 0);
        String level = "";

        if (correctCount == 0 || correctCount == 1) {
            level = "Beginner";
        } else if (correctCount == 2) {
            level = "Elementary";
        } else if (correctCount == 3 || correctCount == 4) {
            level = "Intermediate";
        } else if (correctCount == 5) {
            level = "IELTS";
        }

        // Store the user's level in the map
        userLevels.put(chatId, level);

        SendMessage completeMessage = new SendMessage();
        completeMessage.setChatId(String.valueOf(chatId));
        completeMessage.setParseMode("HTML");
        completeMessage.setText("🎉 Test complete! You answered " + correctCount + " questions correctly.\n\n"
                + "Your English Level is <b>" + level + "</b>.\n\nReady to study? Click the button below!");

        InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup();
        inlineKeyboard.setKeyboard(
                List.of(
                        List.of(
                                InlineKeyboardButton.builder().text("⚡ Let's Study").callbackData("study").build(),
                                InlineKeyboardButton.builder().text("Back").callbackData("back").build()

                        )
                )
        );

        completeMessage.setReplyMarkup(inlineKeyboard);

        try {
            execute(completeMessage);
        } catch (TelegramApiException e) {
            throw new RuntimeException(e);
        }

        // Clear data after sending the completion message
        correctAnswers.remove(chatId);
        currentQuestionIndex.remove(chatId);
    }


    private void sendWelcomeMessage(long chatId) {
        SendMessage welcomeMessage = new SendMessage();
        welcomeMessage.setChatId(String.valueOf(chatId));
        welcomeMessage.setParseMode("HTML");
        welcomeMessage.setText("👋 <b>Hello!</b> Welcome to EngLearnBot! We're thrilled to have you here.\n\n"
                + "🎉 Get ready to dive into the English world! <u>Choose an option below.</u>");

        InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup();
        inlineKeyboard.setKeyboard(
                List.of(
                        List.of(
                                InlineKeyboardButton.builder().text("Take Test").callbackData("test").build(),
                                InlineKeyboardButton.builder().text("Choose Level").callbackData("level").build()
                        )
                )
        );

        welcomeMessage.setReplyMarkup(inlineKeyboard);

        try {
            execute(welcomeMessage);
        } catch (TelegramApiException e) {
            throw new RuntimeException(e);
        }
    }

     void sendResponse(long chatId, String text) {
        SendMessage response = new SendMessage();
        response.setChatId(String.valueOf(chatId));
        response.setText(text);

        try {
            execute(response);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    void Study(long chatId) {
        String userLevel = userLevels.getOrDefault(chatId, "Beginner"); // Default to "Beginner" if not found


        switch (userLevel) {
            case "Beginner":
         Beginner(chatId);
                break;

            case "Elementary":
          Elementray(chatId);
                break;

            case "Intermediate":
        Intermediate(chatId);
                break;

            case "IELTS":
           IELTS(chatId);
                break;
        }

        // Adding the "Translator" button for all levels

    }

    void Beginner(long chatId){
        SendMessage studyMessage = new SendMessage();
        studyMessage.setChatId(String.valueOf(chatId));
        studyMessage.setParseMode("HTML");

        InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup();
        List<List<InlineKeyboardButton>> buttonRows = new ArrayList<>(); // List to hold rows of buttons

        studyMessage.setText("📝 You are at the <b>Beginner</b> level. Choose an option to improve your English:");
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Learn the Alphabet").callbackData("alphabet").build())
        );
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Basic Grammar").callbackData("basic_grammar").build())
        );
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Translator").callbackData("translator").build())
        );

        // Add the "Back" button
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Back").callbackData("back").build())
        );

        inlineKeyboard.setKeyboard(buttonRows); // Setting the inline keyboard

        studyMessage.setReplyMarkup(inlineKeyboard);

        try {
            execute(studyMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }void Elementray(long chatId){
        SendMessage studyMessage = new SendMessage();
        studyMessage.setChatId(String.valueOf(chatId));
        studyMessage.setParseMode("HTML");

        InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup();
        List<List<InlineKeyboardButton>> buttonRows = new ArrayList<>(); // List to hold rows of buttons

        studyMessage.setText("📝 You are at the <b>Elementary</b> level. Choose an option to improve your English:");
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Simple Phrases").callbackData("simple_phrases").build())
        );
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Basic Vocabulary").callbackData("basic_vocab").build())
        );
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Translator").callbackData("translator").build())
        );

        // Add the "Back" button
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Back").callbackData("back").build())
        );

        inlineKeyboard.setKeyboard(buttonRows); // Setting the inline keyboard

        studyMessage.setReplyMarkup(inlineKeyboard);

        try {
            execute(studyMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }void Intermediate(long chatId){
        SendMessage studyMessage = new SendMessage();
        studyMessage.setChatId(String.valueOf(chatId));
        studyMessage.setParseMode("HTML");

        InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup();
        List<List<InlineKeyboardButton>> buttonRows = new ArrayList<>(); // List to hold rows of buttons
        studyMessage.setText("📝 You are at the <b>Intermediate</b> level. Choose an option to improve your English:");
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Advanced Grammar").callbackData("advanced_grammar").build())
        );
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Complex Phrases").callbackData("complex_phrases").build())
        );
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Translator").callbackData("translator").build())
        );

        // Add the "Back" button
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Back").callbackData("back").build())
        );

        inlineKeyboard.setKeyboard(buttonRows); // Setting the inline keyboard

        studyMessage.setReplyMarkup(inlineKeyboard);

        try {
            execute(studyMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }

    }void IELTS(long chatId){
        SendMessage studyMessage = new SendMessage();
        studyMessage.setChatId(String.valueOf(chatId));
        studyMessage.setParseMode("HTML");

        InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup();
        List<List<InlineKeyboardButton>> buttonRows = new ArrayList<>(); // List to hold rows of buttons
        studyMessage.setText("📝 You are at the <b>IELTS</b> level. Choose an option to improve your English:");
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("IELTS Practice Tests").callbackData("ielts_tests").build())
        );
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("IELTS Vocabulary").callbackData("ielts_vocab").build())
        );
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Translator").callbackData("translator").build())
        );

        // Add the "Back" button
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Back").callbackData("back").build())
        );

        inlineKeyboard.setKeyboard(buttonRows); // Setting the inline keyboard

        studyMessage.setReplyMarkup(inlineKeyboard);

        try {
            execute(studyMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }

    }


    void Video(long chatId) {
        SendMessage welcomeMessage = new SendMessage();
        welcomeMessage.setChatId(String.valueOf(chatId));
        welcomeMessage.setParseMode("HTML");
        welcomeMessage.setText("👋 <b>Choose</b> which  lesson you want to see today\uD83E\uDEF6!");

        InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup();
        inlineKeyboard.setKeyboard(
                List.of(
                        List.of(
                                InlineKeyboardButton.builder().text("Alphabet | Kirish ").callbackData("alphabet").build(),
                                InlineKeyboardButton.builder().text("TO BE VERB | 1-dars").callbackData("to_be").build(),
                                InlineKeyboardButton.builder().text("TO BE VERB | Question Forms").callbackData("question").build(),
                                InlineKeyboardButton.builder().text("Present Continuous Tense").callbackData("continuous").build()
                        )
                )
        );

        welcomeMessage.setReplyMarkup(inlineKeyboard);


        try {
            execute(welcomeMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }
    void sendLevel(long chatId){
        SendMessage studyMessage = new SendMessage();
        studyMessage.setChatId(String.valueOf(chatId));
        studyMessage.setParseMode("HTML");

        InlineKeyboardMarkup inlineKeyboard = new InlineKeyboardMarkup();
        List<List<InlineKeyboardButton>> buttonRows = new ArrayList<>(); // List to hold rows of buttons
        studyMessage.setText("📝 That's cool,if you know your level,please choose your level from list below");
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Beginner").callbackData("beginner").build())
        );
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Elementary").callbackData("elemntary").build())
        );
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Intermediate").callbackData("intermediate").build())
        );
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("IELTS").callbackData("ielts").build())
        );

        // Add the "Back" button
        buttonRows.add(
                List.of(InlineKeyboardButton.builder().text("Back").callbackData("back").build())
        );

        inlineKeyboard.setKeyboard(buttonRows); // Setting the inline keyboard

        studyMessage.setReplyMarkup(inlineKeyboard);

        try {
            execute(studyMessage);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }

    }

    @Override
    public String getBotUsername() {
        return "EngLearnBot";
    }

    @Override
    public String getBotToken() {
        // Replace this with your actual bot token
        return "7130751712:AAG5MpaQE2fgNfz7vvnjgUTVyjGiESLR-5E";
    }
}
